import React, { Component } from 'react';
import {Container, Box, Typography, TextField, Button, LinearProgress } from '@material-ui/core';

export class UserFragments extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
        firstName:"",
        lastName:"",
        email:"",
        password:"",
        cnfPassword:"",
        email_error:null,
        password_error:null,
        show_progress: false,
      };
    };
    


    render() {
        return (
            <Container maxWidth="xs">
                <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="30px">                    
                    <Typography varient="h5" color="textSecondary">
                        Add User
                    </Typography>
                    <TextField name='firstName'  label="First Name" id="standard-size-small" type="text" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='lastName'  label="Last Name" id="standard-size-small" type="password" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='email'  label="Email" id="standard-size-small" type="text" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='password' label="Password" id="standard-size-small" type="password" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='cnfPassword' label="Confirm Password" id="standard-size-small" type="password" fullWidth={true} size="small" margin="normal"/>
                    <br/>
                    <br/>
                    <Button variant="contained" size="large" color="primary" margin="normal" fullWidth={true}>
                        Add User
                    </Button>
                    <br/>
                    <br/>
                    {
                        this.state.show_progress?
                        <LinearProgress color="primary" />
                        :null
                    }
                                        
                </Box>
            </Container>
        )
    }
}

export default UserFragments
