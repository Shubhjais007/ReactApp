import React, { useState } from 'react';
import {firebaseAuth} from '../firebase';
import {Redirect} from 'react-router-dom';

const Authenticated = (props) => {

    const [loggedIn, setloggedIn] = useState(null);

    firebaseAuth.onAuthStateChanged((user) => {
        if (user) {
          // User is signed in.
          setloggedIn(true);
        } else {
          // User is signed out.
          setloggedIn(false);
        }
      });

      if(props.nonAuthenticated){
        if(loggedIn===null){
            return "Loading...";
          }
          else if(!loggedIn) {
            return props.children;
          }
          else if(loggedIn) {
            return <Redirect to="/Dashboard"/>;
          }
      }
      else{
        if(loggedIn===null){
            return "Loading...";
          }
          else if(loggedIn) {
            return props.children;
          }
          else if(!loggedIn) {
            return <Redirect to="/Login"/>;
          }
      }
};

export default Authenticated;
