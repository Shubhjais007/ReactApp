import React, { Component } from 'react';
import {Container, Box, Typography, TextField, Button, LinearProgress } from '@material-ui/core';
//import logo from '../Media/embalogo.png'; 

import logo from '../Media/NutriFills_logo.jpg';
//import Dashboard from '../Pages/Dashboard';

//firebase Authentication
import {firebaseAuth, firestore} from '../firebase';
//import { blue } from '@material-ui/core/colors';


//import {} from '@material-ui/core/colors';


class Login extends Component {
    
    constructor(props) {
        super(props)
    
        this.state = {
             email:"",
             password:"",
             email_error:null,
             password_error:null,
             show_progress: false,
             admin_role: false,
        };

        this.handleChange = this.handleChange.bind()
        this.login = this.login.bind()
    }

    handleChange = (e) => {
        this.setState({
            [e.target.name]:e.target.value
        })

    }

    login = () => {
        let data_valid = true;
        
        this.setState({
            email_error:null,
             password_error:null,
        })
        
        if(this.state.email === ""){
            this.setState({
                email_error:"Required!"
            })
            data_valid=false;
        }
        if(this.state.password === ""){            
            this.setState({
                password_error:"Required!"
            })
            data_valid=false;
        }
        if(data_valid){
            this.setState({                
                show_progress: true
            })
        }

        // if(data_valid){
        //     //login Page
        //     firestore.collection("USERS")
        //     .where('email','==', this.state.email)
        //     .where('IsAdmin','==', true)
        //     .get()
        //     .then(querySnapshot=>{
        //         if(!querySnapshot.empty){
        //             //login redirect
                                       
        //             firebaseAuth
        //             .signInWithEmailAndPassword(this.state.email, this.state.password)
        //             .then((res) => {
        //                 console.log("loggedIn successfull !! ");
        //                 this.props.history.replace("/Dashboard")
        //             })
        //             .catch((err) => {
        //                 console.log(err.code);
        //                 if(err.code==="auth/wrong-password"){
        //                     this.setState({   
        //                         password_error:"Worng Password !!",           
        //                         show_progress: false
        //                     });
        //                 }
        //                 else if(err.code==="auth/network-request-failed") {
        //                     this.setState({   
        //                         password_error:"Network Error !!",           
        //                         show_progress: false
        //                     });
        //                 }                        
        //             });
        //         }
        //         else{
        //             this.setState({
        //                 email_error:"Not Allowed !",
        //                 show_progress: false
        //             })
        //         }
        //     })

        if(data_valid){
                //login Page
            firebaseAuth
                .signInWithEmailAndPassword(this.state.email, this.state.password)
                .then((res) => {
                    //login Page
                    firestore.collection("USERS")
                    .where('email','==', this.state.email)
                    .where('IsAdmin','==', true)
                    .get()        
                    .then(querySnapshot=>{
                        if(!querySnapshot.empty){
                            //login redirect 
                            console.log("Admin loggedIn successfull !! ");
                            
                            this.setState({   
                                admin_role: true,           
                                show_progress: false
                            });
                            firebaseAuth
                                .signInWithEmailAndPassword(this.state.email, this.state.password)
                                .then((res) => {
                                    console.log("State of admin role :");
                                    console.log(this.state.admin_role); 
                                    this.props.history.replace("/Dashboard")
                                })
                                .catch((err) => {
                                    console.log(err.code);                                                          
                                });                                  
                           
                        }
                        else{
                            console.log("User loggedIn successfull !! ");
                            //this.props.history.replace("/Dashboard")
                            this.setState({   
                                admin_role: false,           
                                show_progress: false
                            });
                            firebaseAuth
                                .signInWithEmailAndPassword(this.state.email, this.state.password)
                                .then((res) => {
                                    console.log("State of admin role :");
                                    console.log(this.state.admin_role); 
                                    this.props.history.replace("/Dashboard")
                                })
                                .catch((err) => {
                                    console.log(err.code);                                                          
                                });
                        }
                    });                        
                })
                .catch((err) => {
                    console.log(err.code);
                    if(err.code==="auth/wrong-password"){
                        this.setState({   
                            password_error:"Worng Password !!",           
                            show_progress: false
                        });
                    }
                    else if(err.code==="auth/network-request-failed") {
                        this.setState({   
                            password_error:"Network Error !!",           
                            show_progress: false
                        });
                    }
                    else{
                        this.setState({
                            email_error:"Not Allowed !",
                            show_progress: false
                        })
                    }

                });
        }

        this.setState({
            update:true
        })        
    }

    render() {
        return (
            <Container maxWidth="xs">
                <Box bgcolor="#fafafa" boxShadow="3" borderRadius="12px" align='center' p='24px' mt="120px">
                    <img src={logo} height="50px" width="50px" alt="logo"/>                    
                    <Typography varient="h2" color="textSecondary">
                        Admin Login
                    </Typography>
                    <TextField name='email' onChange={this.handleChange}  error={this.state.email_error != null} helperText={this.state.email_error} label="Email" id="standard-size-small" type="text" fullWidth={true} size="small" margin="normal"/>
                    <TextField name='password' onChange={this.handleChange} error={this.state.password_error != null} helperText={this.state.password_error} label="Password" id="standard-size-small" type="password" fullWidth={true} size="small" margin="normal"/>
                    <br/>
                    <br/>
                    <Button variant="contained"  onClick={this.login} size="large" color="primary" margin="normal" fullWidth={true}>
                        Login
                    </Button>
                    <br/>
                    <br/>
                    {
                        this.state.show_progress?
                        <LinearProgress color="primary" />
                        :null
                    }
                    
                    
                </Box>
            </Container>
        );
    }
}

//console.log(this.state.admin_role);
//export const admin = this.state.admin_role;

export default Login;
